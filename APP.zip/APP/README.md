# Valor Real - App iOS

App iOS para consulta de valor de mercado de veículos utilizando o backend Valor Real.

## 📋 Pré-requisitos

- Xcode 15.0 ou superior
- iOS 17.0 ou superior
- Backend rodando em `http://localhost:3000` (para simulador)
- Backend rodando no IP da sua máquina (para dispositivo físico)

## 🚀 Configuração

### 1. Para Simulador (Padrão)

O app já está configurado para funcionar no simulador usando `localhost`. Basta:

1. Certificar que o backend está rodando:
   ```bash
   cd /Users/guipratiko/Documents/Cursor/ValorRealAPP
   node server.js
   ```

2. Abrir o projeto no Xcode e executar no simulador

### 2. Para Dispositivo Físico

Para testar no dispositivo físico, você precisa:

1. **Descobrir o IP da sua máquina:**
   ```bash
   ifconfig | grep "inet " | grep -v 127.0.0.1
   ```
   Ou no Mac: System Preferences > Network > Wi-Fi > Advanced > TCP/IP

2. **Atualizar o IP no código:**
   - Abra `Valor Real/Valor Real/Services/APIService.swift`
   - Altere a linha no `#else`:
   ```swift
   private let baseURL = "http://SEU_IP_AQUI:3000/api"
   ```

3. **Certificar que o dispositivo e o Mac estão na mesma rede Wi-Fi**

4. **Configurar o firewall do Mac** (se necessário):
   - System Preferences > Security & Privacy > Firewall
   - Permitir conexões para Node.js

## 📱 Funcionalidades

- ✅ Consulta de veículo por placa
- ✅ Validação de formato de placa (antigo e novo padrão)
- ✅ Exibição de dados completos do veículo
- ✅ Valor FIPE destacado
- ✅ Informações adicionais (UF, município, situação, etc.)
- ✅ Forçar nova consulta (ignora cache)
- ✅ Interface moderna e intuitiva

## 🏗️ Estrutura do Projeto

```
Valor Real/
├── Models/
│   └── Vehicle.swift          # Modelos de dados
├── Services/
│   └── APIService.swift       # Serviço de comunicação com backend
├── ViewModels/
│   └── ConsultaViewModel.swift # Gerenciamento de estado
├── Views/
│   ├── ConsultaView.swift     # Tela principal de consulta
│   └── ResultadoView.swift    # Tela de exibição de resultados
├── ContentView.swift          # View principal
└── Valor_RealApp.swift        # Entry point
```

## 🔧 Troubleshooting

### Erro de conexão no simulador
- Verifique se o backend está rodando: `curl http://localhost:3000/health`
- Certifique-se de que a porta 3000 não está bloqueada

### Erro de conexão no dispositivo físico
- Verifique se o IP está correto no `APIService.swift`
- Certifique-se de que o dispositivo e o Mac estão na mesma rede
- Verifique o firewall do Mac
- Teste a conexão: `curl http://SEU_IP:3000/health` do dispositivo

### Erro de formato de placa
- Formato antigo: AAA9999 (3 letras + 4 números)
- Formato novo: AAA0X00 (3 letras + 1 número + 1 letra + 2 números)

## 📝 Notas

- O app usa cache de 24 horas do backend
- A opção "Forçar Nova Consulta" ignora o cache
- Todos os dados são salvos no MongoDB pelo backend


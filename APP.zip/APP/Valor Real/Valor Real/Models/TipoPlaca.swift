//
//  TipoPlaca.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import Foundation

enum TipoPlaca: String, CaseIterable {
    case antiga = "Antiga"
    case mercosul = "Mercosul"
}


//
//  Vehicle.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import Foundation

// MARK: - Response Models
struct ConsultaResponse: Codable {
    let success: Bool
    let data: VehicleData
    let timestamp: String
}

struct VehicleData: Codable, Identifiable, Hashable {
    var id: String { placa }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(placa)
    }
    
    static func == (lhs: VehicleData, rhs: VehicleData) -> Bool {
        lhs.placa == rhs.placa
    }
    
    let placa: String
    let marca: String?
    let modelo: String?
    let ano: String?
    let anoModelo: String?
    let cor: String?
    let chassi: String?
    let renavam: String?
    let uf: String?
    let municipio: String?
    let situacao: String?
    let valorFipe: String?
    let valorFipeScore: Int?
    let dadosFipe: [FipeData]?
    let mensagemRetorno: String?
    let fonte: String?
    
    // Campos do MongoDB (ignorados, mas não causam erro)
    let _id: String?
    let dataConsulta: String?
    let ultimaAtualizacao: String?
    let createdAt: String?
    let updatedAt: String?
    let __v: Int?
    
    enum CodingKeys: String, CodingKey {
        case placa, marca, modelo, ano, anoModelo, cor, chassi, renavam, uf, municipio
        case situacao, valorFipe, valorFipeScore, dadosFipe, mensagemRetorno, fonte
        case _id, dataConsulta, ultimaAtualizacao, createdAt, updatedAt, __v
    }
}

struct FipeData: Codable {
    let anoModelo: String
    let codigoFipe: String
    let codigoMarca: Int
    let codigoModelo: Int
    let combustivel: String
    let idValor: Int
    let mesReferencia: String
    let referenciaFipe: Int
    let score: Int
    let siglaCombustivel: String
    let textoMarca: String
    let textoModelo: String
    let textoValor: String
    let tipoModelo: Int
    
    enum CodingKeys: String, CodingKey {
        case anoModelo = "ano_modelo"
        case codigoFipe = "codigo_fipe"
        case codigoMarca = "codigo_marca"
        case codigoModelo = "codigo_modelo"
        case combustivel
        case idValor = "id_valor"
        case mesReferencia = "mes_referencia"
        case referenciaFipe = "referencia_fipe"
        case score
        case siglaCombustivel = "sigla_combustivel"
        case textoMarca = "texto_marca"
        case textoModelo = "texto_modelo"
        case textoValor = "texto_valor"
        case tipoModelo = "tipo_modelo"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        anoModelo = try container.decode(String.self, forKey: .anoModelo)
        codigoFipe = try container.decode(String.self, forKey: .codigoFipe)
        codigoMarca = try container.decode(Int.self, forKey: .codigoMarca)
        
        // codigoModelo pode vir como String ou Int
        if let codigoModeloString = try? container.decode(String.self, forKey: .codigoModelo),
           let codigoModeloInt = Int(codigoModeloString) {
            codigoModelo = codigoModeloInt
        } else {
            codigoModelo = try container.decode(Int.self, forKey: .codigoModelo)
        }
        
        combustivel = try container.decode(String.self, forKey: .combustivel)
        idValor = try container.decode(Int.self, forKey: .idValor)
        mesReferencia = try container.decode(String.self, forKey: .mesReferencia)
        referenciaFipe = try container.decode(Int.self, forKey: .referenciaFipe)
        score = try container.decode(Int.self, forKey: .score)
        siglaCombustivel = try container.decode(String.self, forKey: .siglaCombustivel)
        textoMarca = try container.decode(String.self, forKey: .textoMarca)
        textoModelo = try container.decode(String.self, forKey: .textoModelo)
        textoValor = try container.decode(String.self, forKey: .textoValor)
        tipoModelo = try container.decode(Int.self, forKey: .tipoModelo)
    }
}

// MARK: - Error Models
struct APIError: Codable {
    let error: String
    let message: String?
}


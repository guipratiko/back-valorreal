//
//  ContentView.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ConsultaView()
    }
}

#Preview {
    ContentView()
}

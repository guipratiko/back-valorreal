//
//  APIService.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import Foundation

class APIService {
    static let shared = APIService()
    
    // MARK: - Configuração da URL
    // URL de produção do backend
    private let baseURL = "https://valor-real-back-valorreal.o31xjg.easypanel.host/api"
    
    private init() {}
    
    // MARK: - Consulta de Placa
    func consultarPlaca(_ placa: String) async throws -> VehicleData {
        let urlString = "\(baseURL)/consulta/\(placa)"
        guard let url = URL(string: urlString) else {
            throw APIError.custom("URL inválida")
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 30
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw APIError.custom("Resposta inválida do servidor")
            }
            
            guard httpResponse.statusCode == 200 else {
                if let errorData = try? JSONDecoder().decode(APIError.self, from: data) {
                    throw APIError.custom(errorData.error)
                }
                throw APIError.custom("Erro ao consultar placa: \(httpResponse.statusCode)")
            }
            
            let decoder = JSONDecoder()
            
            do {
                let consultaResponse = try decoder.decode(ConsultaResponse.self, from: data)
                return consultaResponse.data
            } catch let decodingError as DecodingError {
                // Log do erro para debug
                if let jsonString = String(data: data, encoding: .utf8) {
                    print("Erro ao decodificar JSON: \(decodingError)")
                    print("JSON recebido: \(jsonString.prefix(500))")
                }
                throw APIError.custom("Erro ao processar resposta do servidor. Formato de dados inválido.")
            }
        } catch let error as NSError {
            if error.domain == NSURLErrorDomain {
                switch error.code {
                case NSURLErrorNotConnectedToInternet:
                    throw APIError.custom("Sem conexão com a internet. Verifique sua conexão Wi-Fi.")
                case NSURLErrorTimedOut:
                    throw APIError.custom("Tempo de conexão esgotado. Verifique se o servidor está rodando em \(baseURL)")
                case NSURLErrorCannotFindHost, NSURLErrorCannotConnectToHost:
                    throw APIError.custom("Não foi possível conectar ao servidor. Verifique se o backend está rodando e se o IP está correto: \(baseURL)")
                case NSURLErrorNetworkConnectionLost:
                    throw APIError.custom("Conexão perdida. Verifique sua rede.")
                default:
                    throw APIError.custom("Erro de conexão: \(error.localizedDescription)")
                }
            }
            throw error
        }
    }
    
    // MARK: - Forçar Nova Consulta
    func forcarConsulta(_ placa: String) async throws -> VehicleData {
        let urlString = "\(baseURL)/consulta/\(placa)/forcar"
        guard let url = URL(string: urlString) else {
            throw APIError.custom("URL inválida")
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 30
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw APIError.custom("Resposta inválida do servidor")
            }
            
            guard httpResponse.statusCode == 200 else {
                if let errorData = try? JSONDecoder().decode(APIError.self, from: data) {
                    throw APIError.custom(errorData.error)
                }
                throw APIError.custom("Erro ao consultar placa: \(httpResponse.statusCode)")
            }
            
            let decoder = JSONDecoder()
            
            do {
                let consultaResponse = try decoder.decode(ConsultaResponse.self, from: data)
                return consultaResponse.data
            } catch let decodingError as DecodingError {
                // Log do erro para debug
                if let jsonString = String(data: data, encoding: .utf8) {
                    print("Erro ao decodificar JSON: \(decodingError)")
                    print("JSON recebido: \(jsonString.prefix(500))")
                }
                throw APIError.custom("Erro ao processar resposta do servidor. Formato de dados inválido.")
            }
        } catch let error as NSError {
            if error.domain == NSURLErrorDomain {
                switch error.code {
                case NSURLErrorNotConnectedToInternet:
                    throw APIError.custom("Sem conexão com a internet. Verifique sua conexão Wi-Fi.")
                case NSURLErrorTimedOut:
                    throw APIError.custom("Tempo de conexão esgotado. Verifique se o servidor está rodando em \(baseURL)")
                case NSURLErrorCannotFindHost, NSURLErrorCannotConnectToHost:
                    throw APIError.custom("Não foi possível conectar ao servidor. Verifique se o backend está rodando e se o IP está correto: \(baseURL)")
                case NSURLErrorNetworkConnectionLost:
                    throw APIError.custom("Conexão perdida. Verifique sua rede.")
                default:
                    throw APIError.custom("Erro de conexão: \(error.localizedDescription)")
                }
            }
            throw error
        }
    }
}

// MARK: - Custom Error
extension APIError: Error {
    static func custom(_ message: String) -> NSError {
        return NSError(domain: "APIService", code: -1, userInfo: [NSLocalizedDescriptionKey: message])
    }
}


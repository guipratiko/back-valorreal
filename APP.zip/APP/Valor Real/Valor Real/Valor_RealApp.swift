//
//  Valor_RealApp.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import SwiftUI

@main
struct Valor_RealApp: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    }
}

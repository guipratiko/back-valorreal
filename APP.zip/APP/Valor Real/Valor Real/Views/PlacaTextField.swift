//
//  PlacaTextField.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import SwiftUI

struct PlacaTextField: View {
    @Binding var texto: String
    let tipoPlaca: TipoPlaca
    @FocusState.Binding var isFocused: Bool
    let onSubmit: () -> Void
    @State private var keyboardType: UIKeyboardType = .default
    @State private var shouldRefocus: Bool = false
    
    var body: some View {
        TextField(placeholder, text: $texto)
            .textFieldStyle(.roundedBorder)
            .textInputAutocapitalization(.characters)
            .autocorrectionDisabled()
            .keyboardType(keyboardType)
            .focused($isFocused)
            .onChange(of: texto) { newValue in
                // Limita a 7 caracteres
                if newValue.count > 7 {
                    texto = String(newValue.prefix(7))
                    return
                }
                
                // Valida e formata conforme o tipo
                let textoFormatado = formatarTexto(newValue)
                if textoFormatado != newValue {
                    texto = textoFormatado
                }
                
                // Sempre atualiza o teclado quando o texto muda
                atualizarTecladoComFoco()
            }
            .onChange(of: tipoPlaca) { newValue in
                // Atualiza o teclado quando o tipo muda
                atualizarTecladoComFoco()
            }
            .onAppear {
                keyboardType = calcularTeclado()
            }
            .onChange(of: isFocused) { focused in
                // Quando o campo recebe foco, atualiza o teclado
                if focused {
                    atualizarTecladoComFoco()
                }
            }
            .onSubmit {
                onSubmit()
            }
    }
    
    private var placeholder: String {
        switch tipoPlaca {
        case .antiga:
            return "ABC1234"
        case .mercosul:
            return "ABC1C34"
        }
    }
    
    private func calcularTeclado() -> UIKeyboardType {
        let posicao = texto.count
        
        switch tipoPlaca {
        case .antiga:
            // 0-2: letras, 3-6: números
            return posicao < 3 ? .default : .numberPad
        case .mercosul:
            // 0-2: letras, 3: número, 4: letra, 5-6: números
            if posicao < 3 {
                return .default
            } else if posicao == 3 {
                return .numberPad
            } else if posicao == 4 {
                return .default
            } else {
                return .numberPad
            }
        }
    }
    
    private func atualizarTecladoComFoco() {
        let novoTeclado = calcularTeclado()
        
        // Sempre atualiza o tipo de teclado
        if novoTeclado != keyboardType {
            keyboardType = novoTeclado
            
            // Se o campo está focado, força atualização do teclado
            if isFocused {
                shouldRefocus = true
                isFocused = false
                
                // Recupera o foco após um pequeno delay para o teclado atualizar
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                    if shouldRefocus {
                        isFocused = true
                        shouldRefocus = false
                    }
                }
            }
        }
    }
    
    private func formatarTexto(_ texto: String) -> String {
        let textoLimpo = texto.uppercased().replacingOccurrences(of: " ", with: "")
        var resultado = ""
        
        for (index, caractere) in textoLimpo.enumerated() {
            if index >= 7 { break }
            
            let caractereStr = String(caractere)
            
            switch tipoPlaca {
            case .antiga:
                // 0-2: letras, 3-6: números
                if index < 3 {
                    if caractereStr.rangeOfCharacter(from: CharacterSet.letters) != nil {
                        resultado += caractereStr
                    }
                } else {
                    if caractereStr.rangeOfCharacter(from: CharacterSet.decimalDigits) != nil {
                        resultado += caractereStr
                    }
                }
            case .mercosul:
                // 0-2: letras, 3: número, 4: letra, 5-6: números
                if index < 3 {
                    if caractereStr.rangeOfCharacter(from: CharacterSet.letters) != nil {
                        resultado += caractereStr
                    }
                } else if index == 3 {
                    if caractereStr.rangeOfCharacter(from: CharacterSet.decimalDigits) != nil {
                        resultado += caractereStr
                    }
                } else if index == 4 {
                    if caractereStr.rangeOfCharacter(from: CharacterSet.alphanumerics) != nil {
                        resultado += caractereStr
                    }
                } else {
                    if caractereStr.rangeOfCharacter(from: CharacterSet.decimalDigits) != nil {
                        resultado += caractereStr
                    }
                }
            }
        }
        
        return resultado
    }
}


//
//  ConsultaView.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import SwiftUI

struct ConsultaView: View {
    @StateObject private var viewModel = ConsultaViewModel()
    @FocusState private var isPlacaFocused: Bool
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                    
                    Text("Valor Real")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    Text("Consulte o valor de mercado do seu veículo")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 40)
                .padding(.bottom, 30)
                
                // Formulário de Consulta
                VStack(spacing: 20) {
                    VStack(spacing: 16) {
                        // Seletor de Tipo de Placa
                        VStack(spacing: 8) {
                            Text("Tipo de Placa")
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            Picker("Tipo de Placa", selection: $viewModel.tipoPlaca) {
                                ForEach(TipoPlaca.allCases, id: \.self) { tipo in
                                    Text(tipo.rawValue).tag(tipo)
                                }
                            }
                            .pickerStyle(.segmented)
                            .frame(maxWidth: 280)
                            .onChange(of: viewModel.tipoPlaca) { _ in
                                viewModel.tipoPlacaMudou()
                                // Força atualização do teclado quando o tipo muda
                                if isPlacaFocused {
                                    isPlacaFocused = false
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                        isPlacaFocused = true
                                    }
                                }
                            }
                        }
                        
                        // Campo de Placa
                        VStack(spacing: 8) {
                            Text("Placa do Veículo")
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            HStack {
                                PlacaTextField(
                                    texto: $viewModel.placa,
                                    tipoPlaca: viewModel.tipoPlaca,
                                    isFocused: $isPlacaFocused,
                                    onSubmit: {
                                        isPlacaFocused = false
                                        Task {
                                            await viewModel.consultar()
                                        }
                                    }
                                )
                                .frame(maxWidth: 250)
                                
                                if !viewModel.placa.isEmpty {
                                    Button(action: {
                                        viewModel.placa = ""
                                    }) {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundColor(.secondary)
                                    }
                                }
                            }
                            .frame(maxWidth: 280)
                            
                            if let error = viewModel.errorMessage {
                                Text(error)
                                    .font(.caption)
                                    .foregroundColor(.red)
                                    .padding(.top, 4)
                                    .multilineTextAlignment(.center)
                                    .frame(maxWidth: 280)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    // Botão de Consulta
                    Button(action: {
                        isPlacaFocused = false
                        Task {
                            await viewModel.consultar()
                        }
                    }) {
                        HStack {
                            if viewModel.isLoading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            } else {
                                Image(systemName: "magnifyingglass")
                            }
                            Text(viewModel.isLoading ? "Consultando..." : "Consultar")
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(viewModel.isLoading ? Color.gray : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(viewModel.isLoading || viewModel.placa.isEmpty)
                }
                .padding(.horizontal, 24)
                
                Spacer()
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(item: $viewModel.veiculo) { veiculo in
                ResultadoView(veiculo: veiculo)
            }
            .onChange(of: viewModel.mostrarResultado) { newValue in
                if newValue {
                    isPlacaFocused = false
                }
            }
            .onChange(of: viewModel.isLoading) { newValue in
                if newValue {
                    isPlacaFocused = false
                }
            }
        }
    }
}

#Preview {
    ConsultaView()
}


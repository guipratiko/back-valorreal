//
//  SplashView.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import SwiftUI

struct SplashView: View {
    @State private var isActive = false
    @State private var progress: Double = 0.0
    @State private var loadingText = "Carregando"
    
    var body: some View {
        if isActive {
            ConsultaView()
        } else {
            ZStack {
                Color(.systemBackground)
                    .ignoresSafeArea()
                
                VStack(spacing: 40) {
                    Spacer()
                    
                    // Logo
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                    
                    Spacer()
                    
                    // Barra de Progresso Customizada
                    VStack(spacing: 16) {
                        // Barra de progresso
                        GeometryReader { geometry in
                            ZStack(alignment: .leading) {
                                // Fundo da barra
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color(.systemGray5))
                                    .frame(height: 8)
                                
                                // Barra de progresso
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(
                                        LinearGradient(
                                            gradient: Gradient(colors: [.blue, .blue.opacity(0.7)]),
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        )
                                    )
                                    .frame(width: geometry.size.width * progress, height: 8)
                                    .animation(.easeInOut(duration: 0.3), value: progress)
                            }
                        }
                        .frame(height: 8)
                        .frame(width: 280)
                        
                        // Texto de carregamento e porcentagem
                        HStack {
                            Text(loadingText)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            Spacer()
                            
                            Text("\(Int(progress * 100))%")
                                .font(.subheadline)
                                .fontWeight(.semibold)
                                .foregroundColor(.blue)
                        }
                        .frame(width: 280)
                    }
                    .padding(.bottom, 60)
                }
            }
            .onAppear {
                startLoading()
            }
        }
    }
    
    private func startLoading() {
        // Simula carregamento progressivo
        let steps: [Double] = [0.2, 0.4, 0.6, 0.8, 0.95, 1.0]
        let delays: [TimeInterval] = [0.3, 0.4, 0.5, 0.4, 0.3, 0.1]
        
        var currentStep = 0
        
        func updateProgress() {
            guard currentStep < steps.count else {
                // Aguarda um pouco antes de mostrar a tela principal
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        isActive = true
                    }
                }
                return
            }
            
            withAnimation(.easeInOut(duration: delays[currentStep])) {
                progress = steps[currentStep]
            }
            
            // Atualiza texto de carregamento
            if currentStep < steps.count - 1 {
                loadingText = ["Carregando", "Carregando.", "Carregando..", "Carregando..."][currentStep % 4]
            } else {
                loadingText = "Concluído!"
            }
            
            currentStep += 1
            
            DispatchQueue.main.asyncAfter(deadline: .now() + delays[currentStep - 1]) {
                updateProgress()
            }
        }
        
        updateProgress()
    }
}

#Preview {
    SplashView()
}


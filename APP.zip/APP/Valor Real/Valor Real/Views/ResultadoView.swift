//
//  ResultadoView.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import SwiftUI

struct ResultadoView: View {
    let veiculo: VehicleData
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header do Resultado
                VStack(spacing: 8) {
                    Text("Resultado da Consulta")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("Placa: \(veiculo.placa)")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                }
                .padding(.top, 20)
                
                // Informações Principais
                VStack(spacing: 16) {
                    InfoCard(title: "Marca", value: veiculo.marca ?? "N/A", icon: "car.fill")
                    InfoCard(title: "Modelo", value: veiculo.modelo ?? "N/A", icon: "car.side.fill")
                    
                    if let ano = veiculo.ano {
                        InfoCard(title: "Ano Fabricação", value: ano, icon: "calendar")
                    }
                    
                    if let anoModelo = veiculo.anoModelo {
                        InfoCard(title: "Ano Modelo", value: anoModelo, icon: "calendar.badge.clock")
                    }
                    
                    if let cor = veiculo.cor {
                        InfoCard(title: "Cor", value: cor, icon: "paintpalette.fill")
                    }
                    
                    if let valorFipe = veiculo.valorFipe {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Image(systemName: "dollarsign.circle.fill")
                                    .foregroundColor(.green)
                                Text("Valor FIPE")
                                    .font(.headline)
                            }
                            
                            Text(valorFipe)
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.green)
                            
                            if let score = veiculo.valorFipeScore {
                                HStack {
                                    Text("Score: \(score)")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    
                                    Spacer()
                                    
                                    if let fonte = veiculo.fonte {
                                        Text("Fonte: \(fonte.uppercased())")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                }
                            }
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.green.opacity(0.1))
                        .cornerRadius(12)
                    }
                }
                .padding(.horizontal, 24)
                
                // Botão Voltar
                Button(action: {
                    dismiss()
                }) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Voltar para Pesquisa")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                }
                .padding(.horizontal, 24)
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
        }
        .background(Color(.systemBackground))
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct InfoCard: View {
    let title: String
    let value: String
    let icon: String
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.blue)
                .frame(width: 40)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(value)
                    .font(.body)
                    .fontWeight(.medium)
            }
            
            Spacer()
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

#Preview {
    NavigationStack {
        ResultadoView(
            veiculo: VehicleData(
                placa: "ABC1234",
                marca: "VW",
                modelo: "GOL 1.0",
                ano: "2010",
                anoModelo: "2011",
                cor: "PRETA",
                chassi: "*****12345",
                renavam: nil,
                uf: "SP",
                municipio: "São Paulo",
                situacao: "Sem restrição",
                valorFipe: "R$ 28.890,00",
                valorFipeScore: 58,
                dadosFipe: nil,
                mensagemRetorno: "Sem erros.",
                fonte: "api",
                _id: nil,
                dataConsulta: nil,
                ultimaAtualizacao: nil,
                createdAt: nil,
                updatedAt: nil,
                __v: nil
            )
        )
    }
}


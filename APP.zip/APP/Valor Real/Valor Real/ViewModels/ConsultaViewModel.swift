//
//  ConsultaViewModel.swift
//  Valor Real
//
//  Created by Guilherme Augusto Santos on 01/12/25.
//

import Foundation
import SwiftUI
import Combine

@MainActor
class ConsultaViewModel: ObservableObject {
    @Published var placa: String = ""
    @Published var tipoPlaca: TipoPlaca = .antiga
    @Published var veiculo: VehicleData?
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var mostrarResultado: Bool = false
    
    private let apiService = APIService.shared
    
    // Limita o tamanho da placa conforme o tipo
    func formatarPlaca(_ texto: String) -> String {
        let textoLimpo = texto.uppercased().replacingOccurrences(of: " ", with: "")
        let limitado = String(textoLimpo.prefix(7))
        return limitado
    }
    
    // Valida se o caractere pode ser digitado na posição atual
    func podeDigitar(_ caractere: String, naPosicao posicao: Int) -> Bool {
        let caractereUpper = caractere.uppercased()
        
        switch tipoPlaca {
        case .antiga:
            // 0-2: letras, 3-6: números
            if posicao < 3 {
                return caractereUpper.rangeOfCharacter(from: CharacterSet.letters) != nil
            } else {
                return caractereUpper.rangeOfCharacter(from: CharacterSet.decimalDigits) != nil
            }
        case .mercosul:
            // 0-2: letras, 3: número, 4: letra, 5-6: números
            if posicao < 3 {
                return caractereUpper.rangeOfCharacter(from: CharacterSet.letters) != nil
            } else if posicao == 3 {
                return caractereUpper.rangeOfCharacter(from: CharacterSet.decimalDigits) != nil
            } else if posicao == 4 {
                return caractereUpper.rangeOfCharacter(from: CharacterSet.alphanumerics) != nil
            } else {
                return caractereUpper.rangeOfCharacter(from: CharacterSet.decimalDigits) != nil
            }
        }
    }
    
    // MARK: - Validação de Placa
    func validarPlaca(_ placa: String) -> Bool {
        let placaLimpa = placa.replacingOccurrences(of: " ", with: "").uppercased()
        
        switch tipoPlaca {
        case .antiga:
            // Formato antigo: AAA9999 (3 letras + 4 números)
            let formatoAntigo = NSPredicate(format: "SELF MATCHES %@", "^[A-Z]{3}[0-9]{4}$")
            return formatoAntigo.evaluate(with: placaLimpa)
        case .mercosul:
            // Formato Mercosul: AAA0X00 (3 letras + 1 número + 1 letra + 2 números)
            let formatoMercosul = NSPredicate(format: "SELF MATCHES %@", "^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$")
            return formatoMercosul.evaluate(with: placaLimpa)
        }
    }
    
    // MARK: - Consulta
    func consultar() async {
        let placaLimpa = placa.replacingOccurrences(of: " ", with: "").uppercased()
        
        guard !placaLimpa.isEmpty else {
            errorMessage = "Por favor, informe a placa do veículo"
            return
        }
        
        guard placaLimpa.count == 7 else {
            errorMessage = "A placa deve ter exatamente 7 caracteres"
            return
        }
        
        guard validarPlaca(placaLimpa) else {
            let formatoEsperado = tipoPlaca == .antiga ? "ABC1234 (3 letras + 4 números)" : "ABC1C34 (3 letras + 1 número + 1 letra + 2 números)"
            errorMessage = "Formato de placa inválido. Use o formato \(formatoEsperado)"
            return
        }
        
        isLoading = true
        errorMessage = nil
        veiculo = nil
        
        do {
            let resultado = try await apiService.consultarPlaca(placaLimpa)
            veiculo = resultado
            mostrarResultado = true
        } catch {
            errorMessage = error.localizedDescription
            mostrarResultado = false
        }
        
        isLoading = false
    }
    
    // MARK: - Forçar Nova Consulta
    func forcarConsulta() async {
        let placaLimpa = placa.replacingOccurrences(of: " ", with: "").uppercased()
        
        guard !placaLimpa.isEmpty else {
            errorMessage = "Por favor, informe a placa do veículo"
            return
        }
        
        guard placaLimpa.count == 7 else {
            errorMessage = "A placa deve ter exatamente 7 caracteres"
            return
        }
        
        guard validarPlaca(placaLimpa) else {
            let formatoEsperado = tipoPlaca == .antiga ? "ABC1234 (3 letras + 4 números)" : "ABC1C34 (3 letras + 1 número + 1 letra + 2 números)"
            errorMessage = "Formato de placa inválido. Use o formato \(formatoEsperado)"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let resultado = try await apiService.forcarConsulta(placaLimpa)
            veiculo = resultado
            mostrarResultado = true
        } catch {
            errorMessage = error.localizedDescription
            mostrarResultado = false
        }
        
        isLoading = false
    }
    
    // MARK: - Limpar
    func limpar() {
        placa = ""
        veiculo = nil
        errorMessage = nil
        mostrarResultado = false
    }
    
    // Limpa a placa quando o tipo muda
    func tipoPlacaMudou() {
        placa = ""
        errorMessage = nil
    }
}

